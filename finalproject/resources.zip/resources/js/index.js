
console.log('index is working');

import  sportsController from './sportsController.js';

const sportsControllers = new sportsController();
sportsControllers.init();

function toggleNav() {
    var menu_icon = document.getElementById("menu-icon");
var menus = document.getElementById("menu");



menu_icon.classList.toggle("open");
 menus.classList.toggle("active");

}              
           
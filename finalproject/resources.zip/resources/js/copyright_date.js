document.getElementById("currentYear").innerHTML=new Date().getFullYear();

export const todoList={};

